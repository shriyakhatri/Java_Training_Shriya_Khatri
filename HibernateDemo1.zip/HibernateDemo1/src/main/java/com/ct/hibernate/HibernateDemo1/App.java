package com.ct.hibernate.HibernateDemo1;

import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.transform.DistinctRootEntityResultTransformer;


public class App 
{
    public static void main( String[] args )
    {

    	Configuration cf = new Configuration();
    	cf.configure("hibernate.cfg.xml");
    	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
    	Session session = sf.openSession();
    	  session.beginTransaction();
    		
      // Teacher t = new Teacher();
     //  t.setName("shriyaSS");
       //session.save(t);
       
      // Teacher t1=  (Teacher) session.get(Teacher.class, 3);
      // System.out.println(t1.getName());
       //session.delete(t1);
       /*
       String qry = "select t1 from Teacher t1";
       Query qr = session.createQuery(qry);
      System.out.println(qr.list());
      System.out.println(qr);
       */
    	 /* Query query = session.createQuery("from Teacher t1 where t1.id = 1");
    	  Teacher object = (Teacher)query.uniqueResult(); 
          System.out.println(object);
      List<Teacher> l =qr.list() ;*/
     // System.out.println(l);
       
     
    	  /*String qry ="select * from Teacher";
    	  SQLQuery qr = session.createSQLQuery(qry);
    	  qr.addEntity(Teacher.class);
    	  List<Teacher> l = qr.list();
    	  System.out.println(l);
    	  */
          
    	  Criteria crit = session.createCriteria(Teacher.class);
    	  Criterion price = Restrictions.eq("name", "new1");
    	  crit.setResultTransformer(DistinctRootEntityResultTransformer.INSTANCE);
    	  List<Teacher> results = crit.list();
    	  System.out.println(results);
    	  
    	  session.getTransaction().commit();
    	  session.close();
       
   
    }
}
