package com.ct.hibernate.HibernateDemo1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "School")
public class School {
@Id @GeneratedValue
private int id;
private String name;


}
