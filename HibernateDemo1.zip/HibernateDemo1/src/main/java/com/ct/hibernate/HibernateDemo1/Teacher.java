package com.ct.hibernate.HibernateDemo1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Teacher")
public class Teacher {

@Column(name = "pid")
@Id @GeneratedValue
private int id;

public int getId() {
	return id;
}

@Override
public String toString() {
	return "Teacher [id=" + id + ", name=" + name + "]";
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

@Column(name = "pname")
private String name;

}
