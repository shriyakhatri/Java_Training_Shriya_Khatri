package com.ct.Resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path(value = "/hello")
public class Hello {

	@GET
	public String getMessage() {
		return "heloo shriya and nair";
	}
	
}
