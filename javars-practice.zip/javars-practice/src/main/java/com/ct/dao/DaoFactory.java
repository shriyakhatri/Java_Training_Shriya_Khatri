package com.ct.dao;

public final class DaoFactory {

	private static final String IMPL_TYPE="jdbc";
	
	public DaoFactory() {
	}

	public static ContactsDao getContactsDao() throws DaoException {
		switch(IMPL_TYPE) {
		case "jdbc":
			return new JdbcContactsDao();
		default:
			throw new DaoException("No Suitable Implementation Available");
		}
	}
	
}