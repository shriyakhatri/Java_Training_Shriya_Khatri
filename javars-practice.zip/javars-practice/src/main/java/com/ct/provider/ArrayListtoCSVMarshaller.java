package com.ct.provider;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.ArrayList;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

import com.ct.entity.Contact;

@Provider
@Produces("text/csv")
public class ArrayListtoCSVMarshaller implements MessageBodyWriter<ArrayList<Contact>>  {

	@Override
	public long getSize(ArrayList<Contact> arg0, Class<?> arg1, Type arg2, Annotation[] arg3, MediaType arg4) {
		// TODO Auto-generated method stub
		return -1;
	}

	@Override
	public boolean isWriteable(Class<?> arg0, Type arg1, Annotation[] arg2, MediaType arg3) {
		// TODO Auto-generated method stub
   	
return arg0.isAssignableFrom(ArrayList.class);
	}

	@Override
	public void writeTo(ArrayList<Contact> list, Class<?> arg1, Type arg2, Annotation[] arg3, MediaType arg4,
			MultivaluedMap<String, Object> arg5, OutputStream entityStream) throws IOException, WebApplicationException {
		entityStream.write("Id, Name, Gender, Email, Phone, City, Country".getBytes());
		for(Contact arg0:list) {
			String out = String.format("%d,%s,%s,%s,%s,%s,%s\n", arg0.getId(), arg0.getName(), arg0.getGender(), arg0.getEmail(), arg0.getPhone(), arg0.getCity(), arg0.getCountry());
			entityStream.write(out.getBytes());

		}

	
	}

	
}
