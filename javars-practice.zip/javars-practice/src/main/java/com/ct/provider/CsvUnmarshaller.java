package com.ct.provider;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

import com.ct.entity.Contact;
@Provider
@Consumes("text/csv")

public class CsvUnmarshaller implements MessageBodyReader<Contact> {

	@Override
	public boolean isReadable(Class<?> arg0, Type arg1, Annotation[] arg2, MediaType arg3) {
		
		
		// TODO Auto-generated method stub
		return arg0.isAssignableFrom(Contact.class);
	}

	@Override
	public Contact readFrom(Class<Contact> arg0, Type arg1, Annotation[] arg2, MediaType arg3,
			MultivaluedMap<String, String> arg4, InputStream entityStream) throws IOException, WebApplicationException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(entityStream));
		String csv = br.readLine();
		String [] args = csv.split(",");
		Contact c = new Contact();
		try {
		c.setId(new Integer (args[0]));
		}
		catch(NumberFormatException e)
		{
			e.printStackTrace();
			// TODO Auto-generated method stub
		}
		
		c.setName(args[1]);
		c.setGender(args[2]);
		c.setEmail(args[3]);
		c.setPhone(args[4]);
		c.setCity(args[5]);
		c.setCountry(args[6]);
		
		return c;
	}

}
