package com.ct.controller;

public class Mobile {

	
	private int id;
	private String name;
	private String Description;
	private int price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return Description;
	}
	@Override
	public String toString() {
		return "Mobile [id=" + id + ", name=" + name + ", Description=" + Description + ", price=" + price + "]";
	}
	public void setDescription(String description) {
		Description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}



}
