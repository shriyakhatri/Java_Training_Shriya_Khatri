package com.ct.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ct.dao.IProductDao;
import com.ct.dao.ProductDao;
import com.ct.model.Product;
import com.ct.service.IServiceLayer;


@Controller
public class HomeController {
   @Autowired
	IServiceLayer is;
   //ProductDao pd; 
	@RequestMapping("/")
	public String getHomepage() {
		System.out.println("in index");
		return "index";
	}
	
	
	@RequestMapping("/add")
	public ModelAndView  getAddpage() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("product",new Product());
		mv.setViewName("add");
		return mv;
	}

	
	
	
	@RequestMapping("addproduct")
	
	public String storeProductInDb( @Valid @ModelAttribute("product") Product product,BindingResult br ){
		if(br.hasErrors()) {
			//System.out.println(br);
			return "add";
		}
		else {
			int msg = is.saveProduct(product);
			//m.addAttribute("msg", msg);
			return "index";
				
		}
	
	}
	
	@RequestMapping("/searchbyid")
	public String  searchMobile()
	{
		
		System.out.println("search");
		return "search";
		
		
}
	
	@RequestMapping(value="/search" )
	public String  searchById(@RequestParam("id") int pid, HttpServletRequest request)
	{
		
		
		System.out.println(pid);
		Product p = is.searchById(pid);
		
		/*Product p = new Product(); 
		mobile = map.get(mid);*/
		System.out.println(p);
		request.setAttribute("map",p);
		return "displayproduct";
		
		
		
	}
	
	@RequestMapping("/display")
	public ModelAndView  displayMobile(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		Product p = new Product();
		List l = is.display();
		request.setAttribute("products", l);
		System.out.println(l);
		mv.setViewName("display");

		return mv;
}

	

	@RequestMapping("/deletebyid")
	public String  deleteMobile()
	{
		
		System.out.println("delete");
		return "delete";
		
		
}
	
	
	
	@RequestMapping("/delete")
	public ModelAndView  deleteMobile(@RequestParam("id") int pid, HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		is.delete(pid);
		/*Product p = new Product();
		List l = is.display();
		request.setAttribute("products", l);
		System.out.println(l);*/
		mv.setViewName("delete");

		return mv;
}
	
	/*@RequestMapping(value = "addproduct" , method =RequestMethod.POST)
	
	public String storeProductInDb( @RequestBody @Valid @ModelAttribute("product") Product product,BindingResult br ){
		if(br.hasErrors()) {
			//System.out.println(br);
			return "add";
		}
		else {
			int msg = pd.saveProduct(product);
			//m.addAttribute("msg", msg);
			return "index";
				
		}
	*/
	
	
}
