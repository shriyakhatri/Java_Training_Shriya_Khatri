  package com.ct.dao;
import java.util.List;

import org.hibernate.*;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;

import com.ct.model.Product;

@Component
public class ProductDao implements IProductDao {
	
	public int saveProduct(Product p) {
		
		Configuration cf = new Configuration();
    	cf.configure("hibernate.cfg.xml");
    	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
    	Session session = sf.openSession();
        session.beginTransaction();
        session.save(p);
        session.getTransaction().commit();
        session.close();
		return 1;
	
	}

public Product searchById(int id)
{
	Configuration cf = new Configuration();
	cf.configure("hibernate.cfg.xml");
	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
	Session session = sf.openSession();
    session.beginTransaction();  
    
     Product p=  (Product) session.get(Product.class, id);
    
     session.save(p);
     session.getTransaction().commit();
     session.close();
	return p;

}

public List display() {
	
	Configuration cf = new Configuration();
	cf.configure("hibernate.cfg.xml");
	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
	Session session = sf.openSession();
    session.beginTransaction();  
     
    String qry = "select p from Product p";
    Query qr = session.createQuery(qry);
    List<Product> l = qr.list();
   /*
    session.save(p);
    session.getTransaction().commit();
    session.close();*/
    
	return l ;
}


public int delete(int id)
{
	Configuration cf = new Configuration();
	cf.configure("hibernate.cfg.xml");
	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
	Session session = sf.openSession();
    session.beginTransaction();  
    
    Product p =  (Product) session.get(Product.class, id);
    // System.out.println(t1.getName());
    session.delete(p);
	
    
    
    session.getTransaction().commit();
    session.close();
	
	return 1;
}
}



